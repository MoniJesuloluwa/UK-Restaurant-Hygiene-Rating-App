package com.dev.eatingout.ui.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev.eatingout.R;
import com.dev.eatingout.databinding.ItemResultsBinding;
import com.dev.eatingout.models.Establishment;

import java.util.List;

public class EstablismentAdapter extends RecyclerView.Adapter<EstablismentAdapter.Vh> {
    List<Establishment> list;
    Context context;
    ItemClick itemClick;

    public EstablismentAdapter(List<Establishment> list, Context context,ItemClick itemClick) {
        this.list = list;
        this.context = context;
        this.itemClick=itemClick;
    }

    @NonNull
    @Override
    public Vh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.item_results,parent,false);
        return new Vh(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull Vh holder, @SuppressLint("RecyclerView") int position) {
        Establishment establishment=list.get(position);
        holder.binding.tvName.setText(establishment.getBusinessName());
        holder.binding.tvDistance.setVisibility(View.GONE);
        holder.binding.tvPhone.setVisibility(View.GONE);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClick.OnCLick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Vh extends RecyclerView.ViewHolder {
        ItemResultsBinding binding;
        public Vh(@NonNull View itemView) {
            super(itemView);
            binding=ItemResultsBinding.bind(itemView);
        }
    }
}
