package com.dev.eatingout.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity
public class Establishment implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String AddressLine1;
    private String AddressLine2;
    private String AddressLine3;
    private String AddressLine4;
    private String BusinessName;
    private String BusinessType;
    private int BusinessTypeID;
    private int ChangesByServerID;
    private double Distance;
    private int FHRSID;
    private String LocalAuthorityBusinessID;
    private String LocalAuthorityCode;
    private String LocalAuthorityEmailAddress;
    private String LocalAuthorityName;
    private String LocalAuthorityWebSite;
    private boolean NewRatingPending;
    private String Phone;
    private String PostCode;
    private String RatingDate;
    private String RatingKey;
    private String RatingValue;
    private String RightToReply;
    private String SchemeType;
    private Geocode geocode;
    private Scores scores;

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        AddressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        AddressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return AddressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        AddressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return AddressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        AddressLine4 = addressLine4;
    }

    public String getBusinessName() {
        return BusinessName;
    }

    public void setBusinessName(String businessName) {
        BusinessName = businessName;
    }

    public String getBusinessType() {
        return BusinessType;
    }

    public void setBusinessType(String businessType) {
        BusinessType = businessType;
    }

    public int getBusinessTypeID() {
        return BusinessTypeID;
    }

    public void setBusinessTypeID(int businessTypeID) {
        BusinessTypeID = businessTypeID;
    }

    public int getChangesByServerID() {
        return ChangesByServerID;
    }

    public void setChangesByServerID(int changesByServerID) {
        ChangesByServerID = changesByServerID;
    }

    public double getDistance() {
        return Distance;
    }

    public void setDistance(double distance) {
        Distance = distance;
    }

    public int getFHRSID() {
        return FHRSID;
    }

    public void setFHRSID(int FHRSID) {
        this.FHRSID = FHRSID;
    }

    public String getLocalAuthorityBusinessID() {
        return LocalAuthorityBusinessID;
    }

    public void setLocalAuthorityBusinessID(String localAuthorityBusinessID) {
        LocalAuthorityBusinessID = localAuthorityBusinessID;
    }

    public String getLocalAuthorityCode() {
        return LocalAuthorityCode;
    }

    public void setLocalAuthorityCode(String localAuthorityCode) {
        LocalAuthorityCode = localAuthorityCode;
    }

    public String getLocalAuthorityEmailAddress() {
        return LocalAuthorityEmailAddress;
    }

    public void setLocalAuthorityEmailAddress(String localAuthorityEmailAddress) {
        LocalAuthorityEmailAddress = localAuthorityEmailAddress;
    }

    public String getLocalAuthorityName() {
        return LocalAuthorityName;
    }

    public void setLocalAuthorityName(String localAuthorityName) {
        LocalAuthorityName = localAuthorityName;
    }

    public String getLocalAuthorityWebSite() {
        return LocalAuthorityWebSite;
    }

    public void setLocalAuthorityWebSite(String localAuthorityWebSite) {
        LocalAuthorityWebSite = localAuthorityWebSite;
    }

    public boolean isNewRatingPending() {
        return NewRatingPending;
    }

    public void setNewRatingPending(boolean newRatingPending) {
        NewRatingPending = newRatingPending;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getPostCode() {
        return PostCode;
    }

    public void setPostCode(String postCode) {
        PostCode = postCode;
    }

    public String getRatingDate() {
        return RatingDate;
    }

    public void setRatingDate(String ratingDate) {
        RatingDate = ratingDate;
    }

    public String getRatingKey() {
        return RatingKey;
    }

    public void setRatingKey(String ratingKey) {
        RatingKey = ratingKey;
    }

    public String getRatingValue() {
        return RatingValue;
    }

    public void setRatingValue(String ratingValue) {
        RatingValue = ratingValue;
    }

    public String getRightToReply() {
        return RightToReply;
    }

    public void setRightToReply(String rightToReply) {
        RightToReply = rightToReply;
    }

    public String getSchemeType() {
        return SchemeType;
    }

    public void setSchemeType(String schemeType) {
        SchemeType = schemeType;
    }

    public Geocode getGeocode() {
        return geocode;
    }

    public void setGeocode(Geocode geocode) {
        this.geocode = geocode;
    }

    public Scores getScores() {
        return scores;
    }

    public void setScores(Scores scores) {
        this.scores = scores;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
