package com.dev.eatingout.models;

import java.io.Serializable;
import java.util.List;

public class ApiResponse implements Serializable {
    List<Establishment> establishments;
    List<Link> links;
    Meta meta;

    public List<Establishment> getEstablishments() {
        return establishments;
    }

    public void setEstablishments(List<Establishment> establishments) {
        this.establishments = establishments;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}

