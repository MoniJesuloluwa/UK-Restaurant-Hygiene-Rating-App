package com.dev.eatingout.models;

import java.io.Serializable;

public class Geocode implements Serializable {
    String latitude;
    String longtitude;

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }
}
