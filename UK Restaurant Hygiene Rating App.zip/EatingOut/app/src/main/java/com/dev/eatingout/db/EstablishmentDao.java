package com.dev.eatingout.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;

import com.dev.eatingout.models.Establishment;

import java.util.List;

@Dao
public interface EstablishmentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertEstablishment(Establishment establishment);

    @Query("SELECT * FROM Establishment")
    List<Establishment> getAllEstablishments();

    @Transaction
    @Query("DELETE FROM Establishment WHERE id = :queryId")
    void delete(int queryId);

}
