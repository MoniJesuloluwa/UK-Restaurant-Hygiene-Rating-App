package com.dev.eatingout.ui.search;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUiSaveStateControl;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.dev.eatingout.R;
import com.dev.eatingout.databinding.FragmentResultsBinding;
import com.dev.eatingout.models.ApiResponse;
import com.dev.eatingout.ui.adapters.EstablismentAdapter;
import com.dev.eatingout.ui.adapters.ItemClick;
public class ResultsFragment extends Fragment {
    FragmentResultsBinding binding;
    EstablismentAdapter adapter;
    ApiResponse response;

    public ResultsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            response = (ApiResponse) getArguments().getSerializable("data");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentResultsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigateUp();
            }
        });

        if (response.getEstablishments() != null) {
            adapter = new EstablismentAdapter(response.getEstablishments(), requireContext(), new ItemClick() {
                @Override
                public void OnCLick(int pos) {
                    Bundle bundle=new Bundle();
                    bundle.putSerializable("data",response.getEstablishments().get(pos));
                    findNavController(ResultsFragment.this).navigate(R.id.action_resultsFragment_to_detailsFragment,bundle);
                }
            });
            binding.rvResults.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.rvResults.setAdapter(adapter);
        }
    }
}