package com.dev.eatingout.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.dev.eatingout.models.Establishment;

@Database(entities = {Establishment.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})

public abstract class EstablishmentDatabase extends RoomDatabase {
    public abstract EstablishmentDao establishmentDao();

    private static volatile EstablishmentDatabase INSTANCE;

    public static EstablishmentDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (EstablishmentDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    EstablishmentDatabase.class, "establishment_database")
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
