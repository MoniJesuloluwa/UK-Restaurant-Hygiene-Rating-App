package com.dev.eatingout.ui.home;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.eatingout.R;
import com.dev.eatingout.databinding.FragmentLocalDataBinding;
import com.dev.eatingout.db.EstablishmentDatabase;
import com.dev.eatingout.models.Establishment;
import com.dev.eatingout.ui.adapters.EstablismentAdapter;
import com.dev.eatingout.ui.adapters.ItemClick;
import com.dev.eatingout.ui.search.ResultsFragment;

import java.util.ArrayList;
import java.util.List;

public class LocalDataFragment extends Fragment {
    FragmentLocalDataBinding binding;
    List<Establishment> list;
    EstablismentAdapter adapter;

    public LocalDataFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentLocalDataBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        list=new ArrayList<>();
        list= EstablishmentDatabase.getInstance(requireContext()).establishmentDao().getAllEstablishments();
        adapter=new EstablismentAdapter(list, requireContext(), new ItemClick() {
            @Override
            public void OnCLick(int pos) {
                Bundle bundle=new Bundle();
                bundle.putSerializable("data",list.get(pos));
                bundle.putBoolean("offline",true);
                findNavController(LocalDataFragment.this).navigate(R.id.action_localDataFragment_to_detailsFragment,bundle);

            }
        });
        binding.rvData.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvData.setAdapter(adapter);
        if (list.isEmpty()){
            binding.tvNoData.setVisibility(View.VISIBLE);
            binding.rvData.setVisibility(View.GONE);
        }else{
            binding.tvNoData.setVisibility(View.GONE);
            binding.rvData.setVisibility(View.VISIBLE);
        }
    }
}