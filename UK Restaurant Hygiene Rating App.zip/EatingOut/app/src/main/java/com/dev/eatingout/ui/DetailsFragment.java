package com.dev.eatingout.ui;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.dev.eatingout.MainActivity;
import com.dev.eatingout.R;
import com.dev.eatingout.databinding.FragmentDetailsBinding;
import com.dev.eatingout.db.EstablishmentDatabase;
import com.dev.eatingout.models.Establishment;
public class DetailsFragment extends Fragment {
    FragmentDetailsBinding binding;
    Establishment establishment;
    boolean isOffline;

    public DetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            establishment = (Establishment) getArguments().getSerializable("data");
            isOffline = getArguments().getBoolean("offline", false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigateUp();
            }
        });

        if (establishment != null) {
            binding.tvName.setText(establishment.getBusinessName());
            String address1 = establishment.getAddressLine1();
            if (TextUtils.isEmpty(address1)){
                binding.tvAddress1.setText("N\\A");
            }else{
                binding.tvAddress1.setText(address1);
            }
            String address2 = establishment.getAddressLine2();
            if (TextUtils.isEmpty(address2)){
                binding.tvAddress2.setText("N\\A");
            }else{
                binding.tvAddress2.setText(address2);
            }
            String address3 = establishment.getAddressLine3();
            if (TextUtils.isEmpty(address3)){
                binding.tvAddress3.setText("N\\A");
            }else{
                binding.tvAddress3.setText(address3);
            }
            String address4 = establishment.getAddressLine4();
            if (TextUtils.isEmpty(address4)){
                binding.tvAddress4.setText("N\\A");
            }else{
                binding.tvAddress4.setText(address4);
            }
            String getLat = establishment.getGeocode().getLatitude();
            if (TextUtils.isEmpty(getLat)){
                getLat = "N\\A";
            }
            String getLong = establishment.getGeocode().getLongtitude();
            if (TextUtils.isEmpty(getLong)){
                getLong = "N\\A";
            }
            binding.tvGeocode.setText(String.format("Lat: %s Long: %s", getLat, getLong));
            String phone = establishment.getPhone();
            if (TextUtils.isEmpty(phone)){
                binding.tvPhone.setText("N\\A");
            }else{
                binding.tvPhone.setText(phone);
            }
            String rating = establishment.getRatingValue();
            if (TextUtils.isEmpty(rating)){
                binding.tvRatings.setText("N\\A");
            }else{
                binding.tvRatings.setText(rating+" Star");
            }
            String postCode = establishment.getPostCode();
            if (TextUtils.isEmpty(postCode)){
                binding.tvPost.setText("N\\A");
            }else{
                binding.tvPost.setText(postCode);
            }
            if (isOffline) {
                binding.btnSave.setText("Delete");
                binding.btnSave.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.baseline_delete_forever_24));
            }

            binding.btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!isOffline) {
                        EstablishmentDatabase.getInstance(requireContext()).establishmentDao().insertEstablishment(establishment);
                        Toast.makeText(requireContext(), "Successfully Saved", Toast.LENGTH_SHORT).show();
                    } else {
                        EstablishmentDatabase.getInstance(requireContext()).establishmentDao().delete(establishment.getId());
                        Toast.makeText(requireContext(), "Successfully Deleted", Toast.LENGTH_SHORT).show();
                        findNavController(DetailsFragment.this).navigateUp();
                    }

                }
            });

        }
    }

    private void showNotification(Establishment establishment) {
        // Create an intent for the action when the "Save" button is clicked
        Intent saveIntent = new Intent(requireContext(), MainActivity.class);
        // Pass any necessary data to the activity using extras

        PendingIntent savePendingIntent = PendingIntent.getActivity(requireContext(), 0,
                saveIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Create an intent for the action when the notification is clicked
        Intent notificationIntent = new Intent(requireActivity(), MainActivity.class);
        // Pass any necessary data to the activity using extras

        PendingIntent notificationPendingIntent = PendingIntent.getActivity(requireContext(), 0,
                notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        String title = establishment.getBusinessName();
        String content = establishment.getBusinessName()+" Deleted Successfully...";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireActivity(), "your_channel_id1")
                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                .setContentTitle(title)
                .setContentText(content)
                .setAutoCancel(true)
                .addAction(R.drawable.bg_field, "Save", savePendingIntent)
                .setContentIntent(notificationPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(requireActivity());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "eating_out_1";
            String description = "notification_eating_1";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("your_channel_id1", name, importance);
            channel.setDescription(description);

            notificationManager.createNotificationChannel(channel);
        }        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(2, builder.build());
    }

}