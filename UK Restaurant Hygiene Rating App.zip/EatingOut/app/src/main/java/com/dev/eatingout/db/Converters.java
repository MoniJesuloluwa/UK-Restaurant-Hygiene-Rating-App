package com.dev.eatingout.db;

import androidx.room.TypeConverter;

import com.dev.eatingout.models.Geocode;
import com.dev.eatingout.models.Scores;
import com.google.gson.Gson;

public class Converters {
    @TypeConverter
    public static Geocode fromString(String value) {
        return new Gson().fromJson(value, Geocode.class);
    }

    @TypeConverter
    public static String fromGeocode(Geocode geocode) {
        return new Gson().toJson(geocode);
    }

    @TypeConverter
    public static Scores scoresfromString(String value) {
        return new Gson().fromJson(value, Scores.class);
    }

    @TypeConverter
    public static String fromScores(Scores scores) {
        return new Gson().toJson(scores);
    }
}
