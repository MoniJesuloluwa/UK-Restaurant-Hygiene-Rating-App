package com.dev.eatingout.ui.adapters;

public interface ItemClick {
  void   OnCLick(int pos);
}
