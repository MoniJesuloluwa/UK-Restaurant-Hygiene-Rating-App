package com.dev.eatingout.ui.network;


import com.dev.eatingout.models.ApiResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("Establishments")
    Call<ApiResponse> login(@Header("x-api-version") String apiVersion,
                            @Header("Accept") String acceptType,
                            @Header("Content-Type") String contentType, @Query("name") String name, @Query("address") String address, @Query("longitude") String longitude, @Query("latitude")
                            String lat, @Query("maxDistanceLimit") String distance, @Query("ratingKey") String rating,
                            @Query("ratingOperatorKey") String ratingKEy,@Query("localAuthorityId")String authorityId,
                            @Query("countryId")String id
    );

    @GET("businesses")
    Call<ApiResponse> searchBusinesses(@Query("q") String name);
}
