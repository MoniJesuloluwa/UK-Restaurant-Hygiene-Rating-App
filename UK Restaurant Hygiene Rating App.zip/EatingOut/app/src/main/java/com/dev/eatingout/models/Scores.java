package com.dev.eatingout.models;

import java.io.Serializable;

public class Scores implements Serializable {
    Integer ConfidenceInManagement;
    Integer Hygiene;
    Integer Structural;

    public Integer getConfidenceInManagement() {
        return ConfidenceInManagement;
    }

    public void setConfidenceInManagement(Integer confidenceInManagement) {
        ConfidenceInManagement = confidenceInManagement;
    }

    public Integer getHygiene() {
        return Hygiene;
    }

    public void setHygiene(Integer hygiene) {
        Hygiene = hygiene;
    }

    public Integer getStructural() {
        return Structural;
    }

    public void setStructural(Integer structural) {
        Structural = structural;
    }
}
