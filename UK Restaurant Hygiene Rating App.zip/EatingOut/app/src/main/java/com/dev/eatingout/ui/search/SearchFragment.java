package com.dev.eatingout.ui.search;

import static androidx.navigation.fragment.FragmentKt.findNavController;

import static com.dev.eatingout.MainActivity.PERMISSION_REQUEST_CODE;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import com.dev.eatingout.MainActivity;
import com.dev.eatingout.R;
import com.dev.eatingout.databinding.FragmentSearchBinding;
import com.dev.eatingout.models.ApiResponse;
import com.dev.eatingout.ui.network.ApiClient;
import com.dev.eatingout.ui.network.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class SearchFragment extends Fragment {
    FragmentSearchBinding binding;
    ApiInterface apiInterface;
    ProgressDialog progressDialog;
    LocationManager locationManager;
    public SearchFragment() {
        // Required empty public constructor
    }


    public static SearchFragment newInstance(String param1, String param2) {
        SearchFragment fragment = new SearchFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentSearchBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(false);
        locationManager = (LocationManager) requireContext().getSystemService(Context.LOCATION_SERVICE);


        if (ActivityCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(requireContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Request permissions if not granted
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    PERMISSION_REQUEST_CODE);

        } else {
            // Permissions already granted, start requesting location updates
            startLocationUpdates();
        }

        binding.btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = binding.name.getText().toString();
                String address = binding.etAddress.getText().toString();
                String rating = binding.etRating.getText().toString();
                if (rating.isEmpty()){
                    rating = " ";
                }
                String ratingFilter = "GreaterThanOrEqual";
                if (name.isEmpty()) {
                    Toast.makeText(requireContext(), "Name is Required", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (address.isEmpty()) {
                    Toast.makeText(requireContext(), "Address is Required", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressDialog.show();
                apiInterface = ApiClient.getClient().create(ApiInterface.class);
                apiInterface.login("2", "application/json", "application/json", name,
                        address, " ", " ", " ", rating, " "," "," ").enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        progressDialog.dismiss();
                        if (response.isSuccessful() && response.code() == 200) {
                            if (response.body().getMeta().getItemCount() > 0) {
                                Bundle bundle = new Bundle();
                                showNotification(true);
                                bundle.putSerializable("data", response.body());
                                findNavController(SearchFragment.this).navigate(R.id.action_searchFragment_to_resultsFragment, bundle);
                            } else {
                                showNotification(false);
                                Toast.makeText(requireContext(), "No Data Found", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            showNotification(false);
                            Toast.makeText(requireContext(), response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        progressDialog.dismiss();
                        showNotification(false);
                        Toast.makeText(requireContext(), t.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


            }
        });
    }

    private void startLocationUpdates() {
        // Check if the location provider is enabled
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // Request location updates
            if (ActivityCompat.checkSelfPermission(requireContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, (float) 0, new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();
                    binding.etLongitude.setText(latitude+"");
                  binding.etLatitude.setText(longitude+"");
                }
            });
        } else {
            // Location provider is not enabled, show a toast message or handle accordingly
            Toast.makeText(requireContext(), "GPS provider is not enabled", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, start requesting location updates
                startLocationUpdates();
            } else {
                // Permission denied, show a toast message or handle accordingly
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showNotification(boolean isSuccess) {
        // Create an intent for the action when the "Save" button is clicked
        Intent saveIntent = new Intent(requireContext(), MainActivity.class);
        // Pass any necessary data to the activity using extras

        PendingIntent savePendingIntent = PendingIntent.getActivity(requireContext(), 0,
                saveIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Create an intent for the action when the notification is clicked
        Intent notificationIntent = new Intent(requireActivity(), MainActivity.class);
        // Pass any necessary data to the activity using extras

        PendingIntent notificationPendingIntent = PendingIntent.getActivity(requireContext(), 0,
                notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        String title = isSuccess ? "API Result Successful" : "API Result Failed";
        String content = isSuccess ? "Tap to view details and save in database"
                : "Tap to view details";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireActivity(), "your_channel_id")
                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                .setContentTitle(title)
                .setContentText(content)
                .setAutoCancel(true)
                .addAction(R.drawable.bg_field, "Move to Home", savePendingIntent)
                .setContentIntent(notificationPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(requireActivity());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "eating_out";
            String description = "notification_eating";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("your_channel_id", name, importance);
            channel.setDescription(description);

            notificationManager.createNotificationChannel(channel);
        }        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        notificationManager.notify(1, builder.build());
    }



}